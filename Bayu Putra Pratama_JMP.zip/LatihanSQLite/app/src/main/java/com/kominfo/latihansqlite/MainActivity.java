package com.kominfo.latihansqlite;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kominfo.latihansqlite.adapter.Adapter;
import com.kominfo.latihansqlite.helper.DbHelper;
import com.kominfo.latihansqlite.model.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity {

    ListView lvData;
    FloatingActionButton fabAdd;
    AlertDialog.Builder dialog;
    List<Data> itemList = new ArrayList<>();
    Adapter adapter;
    DbHelper SQLite = new DbHelper(this);

    public static final String TAG_ID = "id";
    public static final String TAG_KK = "kk";
    public static final String TAG_JUMLAH = "jumlah";
    public static final String TAG_JIWA = "jiwa";
    public static final String TAG_LATITUDE = "latitude";
    public static final String TAG_LONGITUDE = "longitude";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvData = findViewById(R.id.lv_data);
        fabAdd = findViewById(R.id.fab_add);
        SQLite = new DbHelper(getApplicationContext());

        adapter = new Adapter(MainActivity.this, itemList);
        lvData.setAdapter(adapter);

        fabAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
                startActivity(intent);
            }
        });

        lvData.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final String idx = itemList.get(position).getId();
                final String kk = itemList.get(position).getKk();
                final String jumlah = itemList.get(position).getJumlah();
                final String jiwa = itemList.get(position).getJiwa();
                final String latitude = itemList.get(position).getLatitude();
                final String longitude = itemList.get(position).getLongitude();

                final CharSequence[] dialogItem = {"Edit", "Delete"};
                dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setCancelable(true);
                dialog.setItems(dialogItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Intent intent = new Intent(MainActivity.this, AddEditActivity.class);
                                intent.putExtra(TAG_ID, idx);
                                intent.putExtra(TAG_KK, kk);
                                intent.putExtra(TAG_JUMLAH, jumlah);
                                intent.putExtra(TAG_JIWA, jiwa);
                                intent.putExtra(TAG_LATITUDE, latitude);
                                intent.putExtra(TAG_LONGITUDE, longitude);
                                startActivity(intent);
                                break;
                            case 1:
                                SQLite.delete(Integer.parseInt(idx));
                                itemList.clear();
                                getAllData();
                                break;
                        }
                    }
                }).show();
                return false;
            }
        });
        getAllData();
    }

    private void getAllData(){
        ArrayList<HashMap<String, String>> row = SQLite.getAllData();

        for (int i = 0; i < row.size(); i++) {
            String id = row.get(i).get(TAG_ID);
            String kk = row.get(i).get(TAG_KK);
            String jumlah = row.get(i).get(TAG_JUMLAH);
            String jiwa = row.get(i).get(TAG_JIWA);
            String latitude = row.get(i).get(TAG_LATITUDE);
            String longitude = row.get(i).get(TAG_LONGITUDE);

            Data data = new Data();
            data.setId(id);
            data.setKk(kk);
            data.setJumlah(jumlah);
            data.setJiwa(jiwa);
            data.setLatitude(latitude);
            data.setLongitude(longitude);

            itemList.add(data);

        }
        adapter.notifyDataSetChanged();

    }

    @Override
    protected void onResume() {
        super.onResume();
        itemList.clear();
        getAllData();
    }
}