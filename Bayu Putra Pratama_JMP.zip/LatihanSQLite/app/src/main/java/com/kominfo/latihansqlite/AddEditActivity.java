package com.kominfo.latihansqlite;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kominfo.latihansqlite.helper.DbHelper;

public class AddEditActivity extends AppCompatActivity {

    EditText etId, etKk, etJumlah,etJiwa, etLatitude, etLongitude;
    Button btnSubmit, btnCancel;
    DbHelper SQLite = new DbHelper(this);
    String id, kk, jumlah,jiwa, latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etId = findViewById(R.id.et_id);
        etKk = findViewById(R.id.et_kk);
        etJumlah = findViewById(R.id.et_jumlah);
        etJiwa = findViewById(R.id.et_jiwa);
        etLatitude = findViewById(R.id.et_latitude);
        etLongitude = findViewById(R.id.et_longitude);
        btnSubmit = findViewById(R.id.btn_submit);
        btnCancel = findViewById(R.id.btn_cancel);

        id = getIntent().getStringExtra(MainActivity.TAG_ID);
        kk = getIntent().getStringExtra(MainActivity.TAG_KK);
        jumlah = getIntent().getStringExtra(MainActivity.TAG_JUMLAH);
        jiwa = getIntent().getStringExtra(MainActivity.TAG_JIWA);
        latitude = getIntent().getStringExtra(MainActivity.TAG_LATITUDE);
        longitude = getIntent().getStringExtra(MainActivity.TAG_LONGITUDE);

        if (id == null || id.equals("")){
            setTitle("Add Data");
        } else  {
            setTitle("Edit Data");
            etId.setText(id);
            etKk.setText(kk);
            etJumlah.setText(jumlah);
            etJiwa.setText(jiwa);
            etLatitude.setText(latitude);
            etLongitude.setText(longitude);
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (etId.getText().toString().equals("")) {
                        save();
                    } else {
                        edit();
                    }
                } catch (Exception e) {
                    Log.e("Submit", e.toString());
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blank();
                finish();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                blank();
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void blank() {
        etKk.requestFocus();
        etId.setText(null);
        etKk.setText(null);
        etJumlah.setText(null);
        etJiwa.setText(null);
        etLatitude.setText(null);
        etLongitude.setText(null);
    }

    private void save() {
        if (etKk.getText() == null || etKk.getText().toString().equals("") || etJumlah.getText() == null || etJumlah.getText().toString().equals("")) {
            Toast.makeText(this, "Please input name and address...", Toast.LENGTH_SHORT).show();
        } else {
            SQLite.insert(etKk.getText().toString(), etJumlah.getText().toString());
            blank();
            finish();
        }
    }

    private void edit() {
        if (etKk.getText() == null || etKk.getText().toString().equals("") || etJumlah.getText() == null || etJumlah.getText().toString().equals("")) {
            Toast.makeText(this, "Please input name and address...", Toast.LENGTH_SHORT).show();
        } else {
            SQLite.update(Integer.parseInt(etId.getText().toString()), etKk.getText().toString(), etJumlah.getText().toString());
            blank();
            finish();
        }
    }

}