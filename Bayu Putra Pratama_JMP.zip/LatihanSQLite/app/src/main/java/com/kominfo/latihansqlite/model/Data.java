package com.kominfo.latihansqlite.model;

public class Data {

    private String id;
    private String kk;
    private String jumlah;
    private String jiwa;
    private String latitude;
    private String longitude;

    public Data() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKk() {
        return kk;
    }

    public void setKk(String kk) {
        this.kk = kk;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getJiwa() {
        return jiwa;
    }

    public void setJiwa(String jiwa) {
        this.jiwa = jiwa;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
